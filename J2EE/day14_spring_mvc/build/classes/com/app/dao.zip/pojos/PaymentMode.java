package com.app.pojos;

public enum PaymentMode {
	UPI,NETBANKING,CREDITCARD,DEBITCARD

}
