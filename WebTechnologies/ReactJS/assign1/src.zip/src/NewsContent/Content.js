import React from 'react';

const content = (props) => 
{
    return(
        <div style={{background: 'beige' , padding: '6px'}} className= 'rounded-top'>
            <h3>{props.subheading}</h3>
            <p>{props.article}</p>
            <div class="new rounded-top"></div>
        </div>
    );
}
export default content;