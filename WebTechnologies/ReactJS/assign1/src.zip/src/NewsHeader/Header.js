import React from 'react';
import '../App.css';

const header = (props) => {

    return (
        <div>
        
        <h1 className="App header" >Times OF India</h1>
  
        </div>
    )
    
    
}
export default header;